//
//  BurgerDetail.swift
//  BurgerRecipeSwiftUI
//
//  Created by Gregor Pichler on 14.03.20.
//  Copyright © 2020 Gregor Pichler. All rights reserved.
//

import SwiftUI

struct BurgerDetail: View {
    let burger: Burger
    
    var body: some View {
        VStack(alignment: .leading) {
            Image(burger.imageName)
                .resizable()
                .scaledToFill()
                .frame(minWidth: 0, maxHeight: 400)
                .clipped()
            Text(burger.name)
                .font(.largeTitle)
                .padding()
            Text(burger.bulletedListIngredients)
                .padding()
            Spacer()
        }
        .edgesIgnoringSafeArea(.top)
    }
}

struct BurgerDetail_Previews: PreviewProvider {
    static var previews: some View {
        BurgerDetail(burger: burgers[0])
    }
}
