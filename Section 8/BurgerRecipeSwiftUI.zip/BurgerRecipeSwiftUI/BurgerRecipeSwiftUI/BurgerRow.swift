//
//  BurgerRow.swift
//  BurgerRecipeSwiftUI
//
//  Created by Gregor Pichler on 14.03.20.
//  Copyright © 2020 Gregor Pichler. All rights reserved.
//

import SwiftUI

struct BurgerRow: View {
    let burger: Burger
    
    var body: some View {
        HStack {
            Image(burger.thumbnailName)
                .resizable()
                .frame(width: 64, height: 64)
                .cornerRadius(8)
            
            VStack(alignment: .leading) {
                Text(burger.name)
                    .lineLimit(1)
                    .font(.headline)
                Text(burger.ingredients)
                    .lineLimit(2)
                    .foregroundColor(Color.gray)
                    .font(.caption)
            }
            Spacer()
        }
    }
}

struct BurgerRow_Previews: PreviewProvider {
    static var previews: some View {
        BurgerRow(burger: burgers[0])
            .previewLayout(.fixed(width: 300, height: 70))
    }
}
