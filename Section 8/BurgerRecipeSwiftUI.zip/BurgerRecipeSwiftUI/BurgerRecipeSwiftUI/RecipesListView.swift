//
//  RecipesListView.swift
//  BurgerRecipeSwiftUI
//
//  Created by Gregor Pichler on 14.03.20.
//  Copyright © 2020 Gregor Pichler. All rights reserved.
//

import SwiftUI

let burgers = BurgerModel().burgers

struct RecipesListView: View {
    var body: some View {
        NavigationView {
            List(burgers) { burger in
                NavigationLink(destination: BurgerDetail(burger: burger)) {
                    BurgerRow(burger: burger)
                }
            }
        .navigationBarTitle("Recipes")
        }
    }
}

struct RecipesListView_Previews: PreviewProvider {
    static var previews: some View {
        RecipesListView()
    }
}
