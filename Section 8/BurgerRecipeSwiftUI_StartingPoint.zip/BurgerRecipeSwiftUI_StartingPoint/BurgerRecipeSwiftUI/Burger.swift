//
//  Burger.swift
//  BurgerRecipe
//
//  Created by Gregor Pichler on 25.01.20.
//  Copyright © 2020 Gregor Pichler. All rights reserved.
//

import Foundation

struct Burger: Decodable {

    var name: String
    var ingredients: String
    var imageName: String
    var thumbnailName: String
    var type: BurgerType
    
    var bulletedListIngredients: String {
        var list = ""
          let items = ingredients.split(separator: ",")
          items.forEach { list.append("\u{2022} \($0)\n") }
          return list
    }
}

enum BurgerType: String, Decodable {
    case vegetarian = "vegetarian"
    case meat = "meat"
}
